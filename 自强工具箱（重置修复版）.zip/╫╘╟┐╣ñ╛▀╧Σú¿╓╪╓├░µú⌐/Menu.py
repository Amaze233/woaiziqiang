import sys
import importlib
Y = sys.path[0]
sys.path.append(Y)
X = input("欢迎使用小工具箱，请根据以下提示信息进行操作\n"
          "输入‘1’进行字符串输入并加密\n"
          "输入‘2’进行字符串输入及字典制作\n"
          "输入‘3’进行txt文件读取及二维码生成与保存:")
if X is "1":
    import Frist
elif X is "2":
    import Second
elif X is "3":
    import Third

Z = input("如需直接结束程序请输入'y'\n"
          "如需返回菜单进行其他操作请输入任意值\n"
          "请输入：")
if Z is 'y':
    sys.exit()
elif Z is not 'y':
    while True:
        print("欢迎再次使用小工具箱")
        R = input("输入‘1’进行字符串输入并加密\n"
                  "输入‘2’进行字符串输入及字典制作\n"
                  "输入‘3’进行txt文件读取及二维码生成与保存:")
        if R is "1":
            importlib.reload(Frist)
        elif R is "2":
            importlib.reload(Second)
        elif R is "3":
            importlib.reload(Third)

        M = input("如需直接结束程序请输入'y'\n"
                  "如需返回菜单进行其他操作请输入任意值\n"
                  "请输入：")
        if M is 'y':
            break
        if M is not 'y':
            pass