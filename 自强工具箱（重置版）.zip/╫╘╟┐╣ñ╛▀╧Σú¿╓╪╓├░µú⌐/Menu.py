while True:
    import sys
    Y = sys.path[0]
    sys.path.append(Y)
    X = input("欢迎使用小工具箱，请根据以下提示信息进行操作\n"
              "输入‘1’进行字符串输入并加密\n"
              "输入‘2’进行字符串输入及字典制作\n"
              "输入‘3’进行txt文件读取及二维码生成与保存:")
    if X is "1":
        import Frist
        del Frist
    elif X is "2":
        import Second
        del Second
    elif X is "3":
        import Third
        del Third

    Z = input("如需直接结束程序请输入'y'\n"
              "如需返回菜单进行其他操作请输入'n'\n"
              "请输入：")
    if Z is 'y':
        break
    elif Z is 'n':
        print("欢迎再次使用小工具箱")