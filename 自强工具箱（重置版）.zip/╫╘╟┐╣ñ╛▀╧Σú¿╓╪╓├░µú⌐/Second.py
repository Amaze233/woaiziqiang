try:
    x = input('欢迎使用python字典制作、转换与反转系统\n'
              '请按说明输入字典的键与值\n'
              '注意:\n'
              '输入字典的键和值时请务必按对应顺序输入\n'
              '并且相邻的键或值之间请以空格隔开!!!!!!\n'
              '请输入字典的键：')
    y = input('请输入字典的值：')
    list1 = x.split(" ")
    list2 = y.split(" ")
    the_dict = dict(zip(list1, list2))
    print("您所输入的字典为：", the_dict)
    import json

    json_str = json.dumps(the_dict)
    print("所输字典转换的JSON字符串为：", json_str)
    print("JSON字符串的类型为：", type(json_str))
    the_dict_alter = {}
    for key, value in the_dict.items():
        if value not in the_dict_alter:
            the_dict_alter[value] = [key]
        else:
            the_dict_alter[value].append(key)
    print("反转后的字典为：", the_dict_alter)
    print("反转后字典的类型为", type(the_dict_alter))
except:
    print("输入非法字符，请重新输入！")