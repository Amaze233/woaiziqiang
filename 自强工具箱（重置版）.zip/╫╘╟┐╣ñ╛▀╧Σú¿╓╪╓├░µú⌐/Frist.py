try:
    import base64

    w = input("欢迎使用字符串加解密系统\n"
              "输入'4'进行字符串的加密\n"
              "输入'5'进行字符串的解密\n"
              "请输入：")
    if w is '4':
        str1 = input("请输入需加密的字符串：")
        str2 = base64.b64encode(str1.encode("utf-8"))
        print("加密后的字符串：", str2)
    elif w is '5':
        str3 = input("请输入需解密的字符串：")
        str4 = base64.b64decode(str3).decode("utf-8")
        print("重新解密的字符串：", str4)
except:
    print("输入非法字符，请重新输入！")