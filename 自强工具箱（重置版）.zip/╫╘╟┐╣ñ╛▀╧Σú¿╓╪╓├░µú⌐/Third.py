i = input("欢迎使用QRcode生成系统\n"
          "请将要转化的txt文档放入此py文档的同一类目底下\n"
          "注意！生成的QRcode也将保存于同一类目下\n"
          "请输入要读取的文件名(要加尾缀)：")
file = open(i, "r")
data = file.read()
print(data)
import qrcode
img = qrcode.make(data=data)
img.show()
img.save("自强.jpg")
