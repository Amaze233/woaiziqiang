import java.util.Scanner;
import java.util.LinkedList;

public class P2141 {
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        int X = 0;
        int N = cin.nextInt();
        int [] arr = new int[N];
        for (int i=0;i<N;i++){
            arr[i]=cin.nextInt();
        }
       /* arr.toArray()*/
    }
}
